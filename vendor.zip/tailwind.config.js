const defaultTheme = require('tailwindcss/defaultTheme');

module.exports = {
    purge: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
        './resources/js/**/*.js',
    ],

    theme: {
        extend: {
            fontFamily: {
                sans: ['Nunito', ...defaultTheme.fontFamily.sans],
            },
            gridTemplateColumns: {
                // Simple 16 column grid
                'home': '20% 55% 25%',
            },
            colors:{
                customBg:'#f5f6fa',
                customBlue : '#487eb0'
            },
        },
    },

    variants: {
        extend: {
            opacity: ['disabled'],
            margin: ['first'],
        },
    },

    plugins: [require('@tailwindcss/forms')],
};
